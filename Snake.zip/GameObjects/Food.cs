﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SimpleSnake.GameObjects
{
    public abstract class Food : Point
    {
        protected Food(Wall wall, char foodSymbol, int points) : base(wall.LeftX, wall.TopY)
        {
            this.FoodPoints = points;
            this.wall = wall;
            this.rnd = new Random();
            this.foodSymbol = foodSymbol;
        }

        private readonly Wall wall;
        private char foodSymbol;
        private Random rnd;
        public int FoodPoints { get; private set; }

        public void SetRandomPosition(Queue<Point> snake)
        {
            this.LeftX = rnd.Next(2, wall.LeftX - 2);
            this.TopY = rnd.Next(2, wall.TopY - 2);

            bool isPointOfSnake = snake.Any(x => x.LeftX == this.LeftX && x.TopY == this.TopY);

            while (isPointOfSnake)
            {
                this.LeftX = rnd.Next(2, wall.LeftX - 2);
                this.TopY = rnd.Next(2, wall.TopY - 2);

                isPointOfSnake = snake.Any(x => x.LeftX == LeftX && x.TopY == TopY);
            }

            Console.BackgroundColor = ConsoleColor.Red;
            wall.Draw(this.LeftX, this.TopY, foodSymbol);
            Console.BackgroundColor = ConsoleColor.White;
        }

        public bool isFoodPoint(Point snake)
        {
            return snake.TopY == TopY && snake.LeftX == LeftX;
        }
    }
}
