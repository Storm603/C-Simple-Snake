﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SimpleSnake.GameObjects
{
    public class Wall : Point
    {
        private const char wallLine = '\u25A0';

        public Wall(int leftX, int topY) : base(leftX, topY)
        {
            InitializeBorders();
        }

        private void InitializeBorders()
        {
            SetHorizontalLine(0);
            SetHorizontalLine(this.TopY);

            SetVerticalLine(0);
            SetVerticalLine(this.LeftX - 1);
        }

        private void SetHorizontalLine(int topY)
        {
            for (int i = 0; i < base.LeftX; i++)
            {
                Draw(i, topY, wallLine);
            }

            //for (int i = 0; i < base.LeftX; i++)
            //{
            //    Draw(i, topY, wallLine);
            //}
        }

        private void SetVerticalLine(int leftX)
        {
            for (int i = 0; i < base.TopY; i++)
            {
                Draw(leftX, i , wallLine);
            }

            //for (int i = 0; i < base.TopY; i++)
            //{
            //    Draw(leftX, i, wallLine);
            //}
        }
    }
}
