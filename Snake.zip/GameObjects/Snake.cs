﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SimpleSnake.GameObjects
{
    public class Snake
    {
        public Snake(Wall wall)
        {
            this.wall = wall;
            snake = new Queue<Point>();
            food = new Food[3];
            this.foodIndex = RandomFoodNumber;
            this.GetFoods();
            this.CreateSnake();
        }

        private int foodIndex;
        private Food[] food;
        private Wall wall;
        public Queue<Point> snake { get; private set; }
        private Point snakeHead;

        private int nextLeftX = 0;
        private int nextTopY = 0;

        public void CreateSnake()
        {
            for (int i = 1; i <= 6; i++)
            {
                snake.Enqueue(new Point(2, i));
            }
        }

        public void GetFoods()
        {
            this.food[0] = new FoodHash(this.wall);
            this.food[1] = new FoodDollar(this.wall);
            this.food[2] = new FoodAsterisk(this.wall);
        }

        private void GetNextPoint(Point direction, Point snakeHead)
        {
            this.nextLeftX = direction.LeftX + snakeHead.LeftX;
            this.nextTopY = direction.TopY + snakeHead.TopY;
        }

        public bool IsPointOfWall(Point snake)
        {
            return snake.TopY == 0
        }

        public bool IsMoving()
        {

        }
    }
}
