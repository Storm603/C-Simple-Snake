﻿namespace SimpleSnake.Enums
{
    public enum Direction
    {
        Right,
        Left,
        Down,
        Up,
    }
}
