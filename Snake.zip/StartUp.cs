﻿using System;
using System.Globalization;
using SimpleSnake.GameObjects;

namespace SimpleSnake
{
    using Utilities;

    public class StartUp
    {
        public static void Main()
        {
            ConsoleWindow.CustomizeConsole();

            Wall wall = new Wall(100, 20);

           
            Console.WriteLine();
        }
    }
}
